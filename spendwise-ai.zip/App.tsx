
import React, { useState, useEffect, useCallback } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { AIChat } from './components/AIChat';
import { Spreadsheet } from './components/Spreadsheet';
import { Settings } from './components/Settings';
import { Login } from './components/Login';
import { PinScreen } from './components/PinScreen';
import { Expense, UserProfile, View } from './types';

const App: React.FC = () => {
  const [view, setView] = useState<View>('login');
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('spendwise_user');
    return saved ? JSON.parse(saved) : {
      monthlyIncome: 0,
      weeklyIncome: 0,
      isAuthenticated: false,
      isLocked: false,
    };
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('spendwise_expenses');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('spendwise_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('spendwise_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    if (!user.isAuthenticated) {
      setView('login');
    } else if (user.pin && user.isLocked) {
      setView('pin-lock');
    } else if (view === 'login' || view === 'pin-lock') {
      setView('dashboard');
    }
  }, [user.isAuthenticated, user.pin, user.isLocked]);

  const handleAddExpense = (expense: Omit<Expense, 'id'>) => {
    const totalSpent = expenses.reduce((sum, e) => sum + e.amount, 0);
    if (totalSpent + expense.amount > user.monthlyIncome) {
      alert("Error: You cannot spend more than your monthly income!");
      return false;
    }
    
    const newExpense = {
      ...expense,
      id: Math.random().toString(36).substr(2, 9)
    };
    setExpenses(prev => [newExpense, ...prev]);
    return true;
  };

  const handleUpdateProfile = (updates: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...updates }));
  };

  const handleLogout = () => {
    setUser({
      monthlyIncome: 0,
      weeklyIncome: 0,
      isAuthenticated: false,
      isLocked: false
    });
    setExpenses([]);
    localStorage.removeItem('spendwise_user');
    localStorage.removeItem('spendwise_expenses');
  };

  const renderView = () => {
    switch (view) {
      case 'login':
        return <Login onLogin={(emailOrPhone) => handleUpdateProfile({ email: emailOrPhone, isAuthenticated: true, isLocked: !!user.pin })} />;
      case 'pin-lock':
        return <PinScreen pin={user.pin || ''} onSuccess={() => handleUpdateProfile({ isLocked: false })} />;
      case 'dashboard':
        return <Dashboard expenses={expenses} income={user.monthlyIncome} onAddClick={() => setView('ai-chat')} />;
      case 'ai-chat':
        return <AIChat onAddExpense={handleAddExpense} currentBudget={user.monthlyIncome} totalSpent={expenses.reduce((s, e) => s + e.amount, 0)} />;
      case 'spreadsheet':
        return <Spreadsheet expenses={expenses} />;
      case 'settings':
        return <Settings user={user} onUpdate={handleUpdateProfile} onLogout={handleLogout} />;
      default:
        return <Dashboard expenses={expenses} income={user.monthlyIncome} onAddClick={() => setView('ai-chat')} />;
    }
  };

  return (
    <Layout currentView={view} setView={setView} user={user}>
      {renderView()}
    </Layout>
  );
};

export default App;
