
export interface Expense {
  id: string;
  date: string;
  category: string;
  amount: number;
  description: string;
  aiNote?: string;
}

export interface UserProfile {
  email?: string;
  phone?: string;
  monthlyIncome: number;
  weeklyIncome: number;
  pin?: string;
  isAuthenticated: boolean;
  isLocked: boolean;
}

export type View = 'dashboard' | 'spreadsheet' | 'ai-chat' | 'settings' | 'login' | 'pin-lock';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
