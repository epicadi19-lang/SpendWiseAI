
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function processExpenseQuery(query: string, monthlyIncome: number, totalSpent: number) {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this user input for an expense: "${query}". 
               The user's monthly income is ${monthlyIncome}. 
               They have already spent ${totalSpent} this month. 
               Remaining budget: ${monthlyIncome - totalSpent}.`,
    config: {
      systemInstruction: `You are a helpful financial AI advisor. Extract expense details and provide advice. 
                          If the expense exceeds the remaining budget, warn the user.
                          Suggest if the product is too expensive based on their income (e.g., if a single non-essential item is > 5% of monthly income, consider it expensive).`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          amount: { type: Type.NUMBER, description: "The cost of the product." },
          category: { type: Type.STRING, description: "Category like Food, Travel, etc." },
          description: { type: Type.STRING, description: "Short description of the item." },
          isAffordable: { type: Type.BOOLEAN, description: "Whether the user can afford it given their budget." },
          isExpensiveForIncome: { type: Type.BOOLEAN, description: "Whether this is objectively pricey for their income level." },
          aiNote: { type: Type.STRING, description: "Friendly advice or warning about this specific purchase." }
        },
        required: ["amount", "category", "description", "isAffordable", "isExpensiveForIncome", "aiNote"]
      }
    }
  });

  try {
    return JSON.parse(response.text.trim());
  } catch (e) {
    console.error("Failed to parse AI response", e);
    return null;
  }
}
