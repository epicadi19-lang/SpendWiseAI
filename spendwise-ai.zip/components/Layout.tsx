
import React from 'react';
import { UserProfile, View } from '../types';
import { LayoutDashboard, TableProperties, Bot, Settings as SettingsIcon, LogOut, Lock } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentView: View;
  setView: (v: View) => void;
  user: UserProfile;
}

export const Layout: React.FC<LayoutProps> = ({ children, currentView, setView, user }) => {
  const showNav = user.isAuthenticated && !user.isLocked && currentView !== 'login' && currentView !== 'pin-lock';

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-gray-50">
      {showNav && (
        <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200 sticky top-0 h-screen">
          <div className="p-6">
            <h1 className="text-2xl font-bold text-indigo-600 flex items-center gap-2">
              <span className="p-2 bg-indigo-100 rounded-lg"><Bot className="w-6 h-6" /></span>
              SpendWise
            </h1>
          </div>
          
          <nav className="flex-1 px-4 space-y-2 mt-4">
            <NavBtn active={currentView === 'dashboard'} onClick={() => setView('dashboard')} icon={<LayoutDashboard size={20} />} label="Overview" />
            <NavBtn active={currentView === 'ai-chat'} onClick={() => setView('ai-chat')} icon={<Bot size={20} />} label="AI Advisor" />
            <NavBtn active={currentView === 'spreadsheet'} onClick={() => setView('spreadsheet'} icon={<TableProperties size={20} />} label="Spreadsheet" />
            <NavBtn active={currentView === 'settings'} onClick={() => setView('settings')} icon={<SettingsIcon size={20} />} label="Settings" />
          </nav>

          <div className="p-4 border-t border-gray-100">
            <div className="flex items-center gap-3 p-2 bg-indigo-50 rounded-xl">
              <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center text-white font-bold">
                {user.email?.[0].toUpperCase() || 'U'}
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-semibold truncate">{user.email || user.phone}</p>
                <p className="text-xs text-indigo-600">Premium User</p>
              </div>
            </div>
          </div>
        </aside>
      )}

      <main className="flex-1 flex flex-col relative overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 md:pb-8">
          {children}
        </div>

        {showNav && (
          <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-3 z-50">
            <MobileNavBtn active={currentView === 'dashboard'} onClick={() => setView('dashboard')} icon={<LayoutDashboard size={24} />} />
            <MobileNavBtn active={currentView === 'ai-chat'} onClick={() => setView('ai-chat')} icon={<Bot size={24} />} />
            <MobileNavBtn active={currentView === 'spreadsheet'} onClick={() => setView('spreadsheet')} icon={<TableProperties size={24} />} />
            <MobileNavBtn active={currentView === 'settings'} onClick={() => setView('settings')} icon={<SettingsIcon size={24} />} />
          </nav>
        )}
      </main>
    </div>
  );
};

const NavBtn = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
      active ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-gray-600 hover:bg-gray-100'
    }`}
  >
    {icon}
    {label}
  </button>
);

const MobileNavBtn = ({ active, onClick, icon }: { active: boolean, onClick: () => void, icon: React.ReactNode }) => (
  <button
    onClick={onClick}
    className={`p-3 rounded-2xl transition-all ${
      active ? 'text-indigo-600' : 'text-gray-400'
    }`}
  >
    {icon}
  </button>
);
