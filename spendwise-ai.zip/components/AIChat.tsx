
import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, User, Loader2, DollarSign, Tag, AlertCircle } from 'lucide-react';
import { processExpenseQuery } from '../services/gemini';
import { Expense, ChatMessage } from '../types';

interface AIChatProps {
  onAddExpense: (expense: Omit<Expense, 'id'>) => boolean;
  currentBudget: number;
  totalSpent: number;
}

export const AIChat: React.FC<AIChatProps> = ({ onAddExpense, currentBudget, totalSpent }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Hi! I am your SpendWise Assistant. Tell me what you bought today, and I\'ll help you track it!' }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [messages, isProcessing]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isProcessing) return;

    const userText = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setIsProcessing(true);

    const result = await processExpenseQuery(userText, currentBudget, totalSpent);

    if (result) {
      const { amount, category, description, isAffordable, isExpensiveForIncome, aiNote } = result;
      
      let botText = `${aiNote}\n\n*Details:*\n- Category: ${category}\n- Cost: $${amount}\n- Status: ${isAffordable ? '✅ Within budget' : '❌ Over budget'}`;
      if (isExpensiveForIncome) {
        botText += `\n⚠️ Note: This item seems a bit pricey for your current income level.`;
      }

      setMessages(prev => [...prev, { role: 'model', text: botText }]);

      if (isAffordable) {
        // Automatically ask if they want to save it
        setMessages(prev => [...prev, { role: 'model', text: 'Should I add this to your spreadsheet?' }]);
      }
      
      // Store pending action in state if needed, but for simplicity we'll show an "Add" button in message
      // Actually, let's just use the result directly to trigger a confirmation UI in the chat
    } else {
      setMessages(prev => [...prev, { role: 'model', text: "I couldn't quite understand that. Could you tell me what you bought and how much it cost?" }]);
    }
    setIsProcessing(false);
  };

  const handleConfirmAdd = (data: any) => {
    const success = onAddExpense({
      date: new Date().toISOString(),
      category: data.category,
      amount: data.amount,
      description: data.description,
      aiNote: data.aiNote
    });

    if (success) {
      setMessages(prev => [...prev, { role: 'model', text: 'Added to your spreadsheet! ✅' }]);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] md:h-[calc(100vh-64px)] bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-4 border-b border-gray-100 bg-gray-50 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg">
            <Bot size={20} />
          </div>
          <div>
            <h3 className="font-bold text-gray-800">SpendWise Assistant</h3>
            <p className="text-xs text-emerald-500 font-medium">Online • Instant Advice</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-gray-400">Budget Remaining</p>
          <p className="font-bold text-indigo-600">${(currentBudget - totalSpent).toLocaleString()}</p>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-4 rounded-2xl ${
              msg.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none shadow-md' 
                : 'bg-gray-100 text-gray-800 rounded-tl-none'
            }`}>
              <div className="whitespace-pre-wrap text-sm leading-relaxed">{msg.text}</div>
              {msg.role === 'model' && msg.text.includes('Cost: $') && !msg.text.includes('Added') && (
                <div className="mt-4 flex gap-2">
                   <button 
                    onClick={() => {
                      // Hacky extraction for demonstration
                      const amountStr = msg.text.match(/Cost: \$(\d+\.?\d*)/)?.[1];
                      const catStr = msg.text.match(/Category: (.*)/)?.[1];
                      const desc = msg.text.split('\n')[0];
                      if (amountStr && catStr) {
                        handleConfirmAdd({
                          amount: parseFloat(amountStr),
                          category: catStr,
                          description: desc,
                          aiNote: desc
                        });
                      }
                    }}
                    className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 transition-colors"
                  >
                    Confirm & Save
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
        {isProcessing && (
          <div className="flex justify-start">
            <div className="bg-gray-100 p-4 rounded-2xl rounded-tl-none flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
              <span className="text-xs font-medium text-gray-500">Analyzing your purchase...</span>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t border-gray-100 bg-gray-50">
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ex: I bought a coffee for $4.50"
            className="w-full pl-4 pr-12 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none shadow-sm"
          />
          <button
            type="submit"
            disabled={!input.trim() || isProcessing}
            className="absolute right-2 top-2 p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-all"
          >
            <Send size={18} />
          </button>
        </div>
      </form>
    </div>
  );
};
