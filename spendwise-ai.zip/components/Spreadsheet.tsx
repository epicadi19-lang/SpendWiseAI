
import React from 'react';
import { Expense } from '../types';
import { Download, FileSpreadsheet, Search } from 'lucide-react';

interface SpreadsheetProps {
  expenses: Expense[];
}

export const Spreadsheet: React.FC<SpreadsheetProps> = ({ expenses }) => {
  const downloadCSV = () => {
    const headers = ['Date', 'Category', 'Description', 'Amount', 'AI Advice'];
    const rows = expenses.map(e => [
      new Date(e.date).toLocaleDateString(),
      e.category,
      e.description,
      e.amount.toFixed(2),
      e.aiNote || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `spendwise-report-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-800">Financial Ledger</h2>
          <p className="text-gray-500">Your full transaction history</p>
        </div>
        <button
          onClick={downloadCSV}
          className="flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
        >
          <Download size={20} />
          Export to CSV
        </button>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Date</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Category</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Description</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider text-right">Amount</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">Insights</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {expenses.length > 0 ? (
                expenses.map((expense) => (
                  <tr key={expense.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {new Date(expense.date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-600 text-xs font-bold">
                        {expense.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-gray-800">
                      {expense.description}
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-right text-rose-500">
                      -${expense.amount.toFixed(2)}
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-xs text-gray-500 italic truncate max-w-xs">
                        {expense.aiNote || 'No AI insights available'}
                      </p>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-400">
                    <div className="flex flex-col items-center gap-2">
                      <FileSpreadsheet size={48} className="text-gray-200" />
                      <p>No transactions found</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
