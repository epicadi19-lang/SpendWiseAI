
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Expense } from '../types';
import { Wallet, TrendingDown, ArrowUpRight, DollarSign, Plus } from 'lucide-react';

interface DashboardProps {
  expenses: Expense[];
  income: number;
  onAddClick: () => void;
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export const Dashboard: React.FC<DashboardProps> = ({ expenses, income, onAddClick }) => {
  const totalSpent = expenses.reduce((sum, e) => sum + e.amount, 0);
  const remaining = Math.max(0, income - totalSpent);
  const usagePercentage = income > 0 ? (totalSpent / income) * 100 : 0;

  const categoryData = expenses.reduce((acc: any[], curr) => {
    const existing = acc.find(item => item.name === curr.category);
    if (existing) {
      existing.value += curr.amount;
    } else {
      acc.push({ name: curr.category, value: curr.amount });
    }
    return acc;
  }, []);

  const recentExpenses = expenses.slice(0, 5);

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-gray-800">Financial Pulse</h2>
          <p className="text-gray-500">Track your progress and stay on budget</p>
        </div>
        <button
          onClick={onAddClick}
          className="flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 whitespace-nowrap"
        >
          <Plus size={20} />
          Add Expense
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          label="Total Balance" 
          value={`$${remaining.toLocaleString()}`} 
          subtext="Available to spend"
          icon={<Wallet className="text-indigo-600" />}
          color="bg-indigo-50"
        />
        <StatCard 
          label="Total Income" 
          value={`$${income.toLocaleString()}`} 
          subtext="Monthly target"
          icon={<ArrowUpRight className="text-emerald-600" />}
          color="bg-emerald-50"
        />
        <StatCard 
          label="Expenses" 
          value={`$${totalSpent.toLocaleString()}`} 
          subtext={`${usagePercentage.toFixed(1)}% of budget used`}
          icon={<TrendingDown className="text-rose-600" />}
          color="bg-rose-50"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold mb-6">Spending by Category</h3>
          <div className="h-64">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-400">
                No expense data yet
              </div>
            )}
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold mb-6">Recent Transactions</h3>
          <div className="space-y-4">
            {recentExpenses.length > 0 ? (
              recentExpenses.map((expense) => (
                <div key={expense.id} className="flex items-center justify-between p-3 rounded-2xl hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
                      <DollarSign className="text-gray-500" size={18} />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">{expense.description}</p>
                      <p className="text-xs text-gray-400">{expense.category} • {new Date(expense.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <p className="font-bold text-rose-500">-${expense.amount.toFixed(2)}</p>
                </div>
              ))
            ) : (
              <div className="h-full py-12 flex items-center justify-center text-gray-400 italic">
                Start adding expenses via AI Chat
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, subtext, icon, color }: { label: string, value: string, subtext: string, icon: React.ReactNode, color: string }) => (
  <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex items-start gap-4">
    <div className={`p-3 rounded-2xl ${color}`}>
      {icon}
    </div>
    <div>
      <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">{label}</p>
      <h4 className="text-2xl font-bold text-gray-900 mt-1">{value}</h4>
      <p className="text-xs text-gray-400 mt-1">{subtext}</p>
    </div>
  </div>
);
