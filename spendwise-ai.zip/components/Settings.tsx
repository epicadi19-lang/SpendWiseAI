
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Save, Lock, DollarSign, LogOut, Shield } from 'lucide-react';

interface SettingsProps {
  user: UserProfile;
  onUpdate: (updates: Partial<UserProfile>) => void;
  onLogout: () => void;
}

export const Settings: React.FC<SettingsProps> = ({ user, onUpdate, onLogout }) => {
  const [income, setIncome] = useState(user.monthlyIncome.toString());
  const [pin, setPin] = useState(user.pin || '');

  const handleSave = () => {
    const val = parseFloat(income) || 0;
    onUpdate({
      monthlyIncome: val,
      weeklyIncome: val / 4,
      pin: pin.trim() || undefined
    });
    alert("Settings saved successfully!");
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-gray-800">Configuration</h2>
        <p className="text-gray-500">Manage your financial targets and security</p>
      </div>

      <div className="space-y-6">
        <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
              <DollarSign size={24} />
            </div>
            <h3 className="text-xl font-bold">Income Settings</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Monthly Income Target ($)</label>
              <input
                type="number"
                value={income}
                onChange={(e) => setIncome(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none"
                placeholder="e.g. 5000"
              />
              <p className="text-xs text-gray-400 mt-2">SpendWise will prevent expenses exceeding this amount.</p>
            </div>
          </div>
        </section>

        <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg">
              <Shield size={24} />
            </div>
            <h3 className="text-xl font-bold">Privacy & Security</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Security PIN (4-Digits)</label>
              <input
                type="password"
                maxLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
                placeholder="Set 4-digit PIN"
              />
              <p className="text-xs text-gray-400 mt-2">Required to open the app once set.</p>
            </div>
          </div>
        </section>

        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={handleSave}
            className="flex-1 flex items-center justify-center gap-2 px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            <Save size={20} />
            Update Preferences
          </button>
          <button
            onClick={onLogout}
            className="flex items-center justify-center gap-2 px-8 py-4 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all"
          >
            <LogOut size={20} />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};
