
import React, { useState } from 'react';
import { Mail, Phone, Bot, ArrowRight } from 'lucide-react';

interface LoginProps {
  onLogin: (emailOrPhone: string) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [value, setValue] = useState('');
  const [type, setType] = useState<'email' | 'phone'>('email');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value.trim()) {
      onLogin(value);
    }
  };

  return (
    <div className="fixed inset-0 bg-indigo-600 flex items-center justify-center p-4 z-[100]">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-8 md:p-12">
        <div className="flex flex-col items-center text-center mb-10">
          <div className="w-20 h-20 bg-indigo-100 rounded-3xl flex items-center justify-center text-indigo-600 mb-6 animate-bounce">
            <Bot size={40} />
          </div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">SpendWise AI</h1>
          <p className="text-gray-500 mt-2 font-medium">Smart Finance for the Modern Age</p>
        </div>

        <div className="flex gap-2 mb-8 bg-gray-100 p-1.5 rounded-2xl">
          <button
            onClick={() => setType('email')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-sm transition-all ${
              type === 'email' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'
            }`}
          >
            <Mail size={16} />
            Email
          </button>
          <button
            onClick={() => setType('phone')}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-sm transition-all ${
              type === 'phone' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'
            }`}
          >
            <Phone size={16} />
            Phone
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest pl-2">
              {type === 'email' ? 'Email Address' : 'Phone Number'}
            </label>
            <input
              required
              type={type === 'email' ? 'email' : 'tel'}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="w-full px-6 py-4 rounded-2xl border-2 border-gray-100 focus:border-indigo-600 outline-none transition-all font-medium"
              placeholder={type === 'email' ? 'name@example.com' : '+1 (555) 000-0000'}
            />
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100"
          >
            Get Started
            <ArrowRight size={22} />
          </button>
        </form>

        <p className="mt-8 text-center text-gray-400 text-sm font-medium">
          By continuing, you agree to our <span className="text-indigo-600 underline">Terms</span> and <span className="text-indigo-600 underline">Privacy Policy</span>
        </p>
      </div>
    </div>
  );
};
