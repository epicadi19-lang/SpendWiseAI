
import React, { useState } from 'react';
import { ShieldAlert, Delete } from 'lucide-react';

interface PinScreenProps {
  pin: string;
  onSuccess: () => void;
}

export const PinScreen: React.FC<PinScreenProps> = ({ pin, onSuccess }) => {
  const [input, setInput] = useState('');
  const [error, setError] = useState(false);

  const handleDigit = (digit: string) => {
    if (input.length >= 4) return;
    const newInput = input + digit;
    setInput(newInput);
    
    if (newInput.length === 4) {
      if (newInput === pin) {
        onSuccess();
      } else {
        setError(true);
        setTimeout(() => {
          setInput('');
          setError(false);
        }, 800);
      }
    }
  };

  const handleDelete = () => {
    setInput(prev => prev.slice(0, -1));
  };

  return (
    <div className="fixed inset-0 bg-white z-[200] flex flex-col items-center justify-center p-6">
      <div className="flex flex-col items-center mb-12">
        <div className={`p-4 rounded-3xl ${error ? 'bg-rose-100 text-rose-600' : 'bg-indigo-100 text-indigo-600'} mb-6 transition-colors`}>
          <ShieldAlert size={32} />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">App Locked</h2>
        <p className="text-gray-500 font-medium">Enter your 4-digit PIN</p>
      </div>

      <div className="flex gap-4 mb-16">
        {[...Array(4)].map((_, i) => (
          <div
            key={i}
            className={`w-4 h-4 rounded-full border-2 transition-all ${
              error 
                ? 'bg-rose-500 border-rose-500 scale-110' 
                : i < input.length 
                  ? 'bg-indigo-600 border-indigo-600 scale-110' 
                  : 'bg-transparent border-gray-200'
            }`}
          />
        ))}
      </div>

      <div className="grid grid-cols-3 gap-6 w-full max-w-xs">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
          <button
            key={num}
            onClick={() => handleDigit(num.toString())}
            className="aspect-square rounded-full flex items-center justify-center text-2xl font-bold text-gray-700 hover:bg-gray-100 active:bg-gray-200 transition-colors"
          >
            {num}
          </button>
        ))}
        <div />
        <button
          onClick={() => handleDigit('0')}
          className="aspect-square rounded-full flex items-center justify-center text-2xl font-bold text-gray-700 hover:bg-gray-100 active:bg-gray-200 transition-colors"
        >
          0
        </button>
        <button
          onClick={handleDelete}
          className="aspect-square rounded-full flex items-center justify-center text-rose-500 hover:bg-rose-50 active:bg-rose-100 transition-colors"
        >
          <Delete size={24} />
        </button>
      </div>

      <p className="mt-12 text-sm text-gray-400 font-medium cursor-pointer hover:text-indigo-600 transition-colors">
        Forgot PIN?
      </p>
    </div>
  );
};
